#!/bin/bash
#描述:用于对封魔服务端的开启和关闭
#2013-07-11新增关闭时对缓存写到数据库的检测
#作者:柳青
#创建时间:2013-07-06
#导入当前环境变量
export PATH=$PATH:/bin:/usr/bin:/usr/local/bin:/bin:/usr/local/mysql/bin
export LANG=C
HOME=$(cd $(dirname $0);pwd)
#将所有数据都重定向到错误输出
#获取当前程序路径下的jar文件名称
cd ${HOME}
SERVERPROC=`ls -lh $HOME | grep '_fengmo.jar' | awk '{print $9}'`
LOGDIR=/usr/local/gamelog
#获取服务端文件名称
SERVERNAME=`echo "$HOME" | awk -F '/' '{print $5}'`
echo $SERVERNAME
SERVERPORT=`echo "$SERVERNAME" | awk -F '_' '{print $NF}'`
#获取脚本名称
SERVERD=$(basename $0)
#获取外网网卡地址
IPADDR=`/sbin/ip addr ls eth0 | grep -w inet | grep -v 'secondary' |  awk '{ split($2, arr, "/"); print arr[1]; }'`

pidinfo()
{
SERVERPID=`ps -ef | grep $SERVERPROC | grep -v grep | awk '{print $2}'`
if [ "$SERVERPID"x = "x" ]
then
return 0
else
return 1
fi
}

fengmo_status()
{
SERVERSTATE=$1
SERVERPID=`ps -ef | grep $SERVERPROC | grep -v grep | awk '{print $2}'`
LISTENNUM=`netstat -na | grep "${IPADDR}:${SERVERPORT}" |grep -i estab | grep -v grep | wc -l`
if [ ${SERVERSTATE}x = "startx" ];then
if [ "$SERVERPID"x = "x" ]
then
return 1
else
return 0
fi
fi
if [ ${SERVERSTATE}x = "stopx" ];then
if [ "$SERVERPID"x = "x"  -a  "$LISTENNUM" -eq 0 ]
then
return 1
else
return 0
fi
fi
}

fengmo_start()
{
#检测目录权限
checkuser=`ls -lh $LOGDIR/${SERVERNAME}log/log.log| awk '{print $3}'`
if [[ "$checkuser" != "root" ]];then
echo -e "\033[1;31m日志权限检测失败，当前日志权限是:$checkuser...[Fail]\033[0m"
exit
fi
(java -jar -server -Xmx8g -Xms8g -Xmn1024m -Xss512k -XX:PermSize=256m -XX:MaxPermSize=512m -XX:NewRatio=4 -XX:+UseConcMarkSweepGC -XX:+UseParNewGC -XX:SurvivorRatio=5 -XX:TargetSurvivorRatio=70 -XX:CMSInitiatingOccupancyFraction=70 -XX:MaxTenuringThreshold=20 -XX:+UseCMSCompactAtFullCollection -XX:+CMSPermGenSweepingEnabled -XX:+CMSClassUnloadingEnabled ${SERVERNAME}_fengmo.jar > "${LOGDIR}/${SERVERNAME}log/${SERVERNAME}.log" 2>&1 &)
#检测进程是否成功开启
fengmo_status 'start'
if [ $? -eq 0 ]
then
echo "$SERVERPROC 开启成功,请等待端口号:${SERVERPORT}建立连接..."
else
echo "$SERVERPROC 开启失败,请检查原因..."
fi
}

fengmo_stop()
{
kill $SERVERPID
echo "已经执行kill $SERVERPID操作，请稍等2s..."
sleep 2
pidinfo
if [ $? -eq 0 ];then
echo "进程关闭成功...[OK]"
else
echo "进程还未关闭成功，等待缓存数据写入..."
COUNT=0
while [ "$COUNT" -le 60 ]
do
echo "sleep $COUNT"
sleep 1
LOGNUM=`tail -n 1 "${LOGDIR}/${SERVERNAME}log/log.log" | grep 'shutdown server==============end dump to database...' | grep -v grep | wc -l`
if [ "$LOGNUM" -eq 1 ]
then
echo "数据库日志已经成功刷新到数据库..."
break
fi
COUNT=$((COUNT+1))
done
fi
fengmo_status 'stop'
#检测进程是否关闭
PIDCOUNT=0
while [ "$PIDCOUNT" -le 10 ]
do
pidinfo
if [ $? -eq 0 ];then
echo "$SERVERPROC 关闭成功..."
break
else
sleep 1
echo "等待$SERVERPROC 进程释放中:$PIDCOUNT..."
PIDCOUNT=$((PIDCOUNT+1))
fi
done
}

case "$1" in

        start)
		fengmo_status 'start'
                if [ $? -eq 0 ]; then
                        echo "$SERVERPROC 在运行中..."
                        exit 1
                fi
                echo -n "开启 $SERVERPROC:"
		fengmo_start
                ;;

        stop)
		fengmo_status 'stop'
                if [ $? -eq 1 ]; then
                        echo "$SERVERPROC 不在运行中... 无法停止"
                        exit 1
		fi
		fengmo_stop
                ;;

        status)
		echo "进程情况:"
		ps -ef | grep $SERVERPROC | grep -v grep
		echo "------------------------------------------------------------------------------------------------------"
		echo "监听端口:"
                netstat -na | grep ":::${SERVERPORT}" | grep -v grep
                netstat -na | grep "${IPADDR}:${SERVERPORT}" | grep -i 'estab' | grep -v grep | head
	        echo ".........." 	
                ;;

        restart)
                $0 stop
                $0 start
                ;;

        *)
                echo "Usage: $SERVERD {start|stop|restart|status}"
                exit 1
                ;;

esac
